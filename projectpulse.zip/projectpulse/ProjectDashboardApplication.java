package com.cds.projectpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDashboardApplication.class, args);
	}

}
